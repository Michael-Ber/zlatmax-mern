import React from 'react'

export const NewsPage = () => {
  return (
    <div className="news" style={{padding: "100px 20px"}}>

      <h1 style={{textAlign: 'center'}}>Страница новостей</h1>
    </div>
  )
}
