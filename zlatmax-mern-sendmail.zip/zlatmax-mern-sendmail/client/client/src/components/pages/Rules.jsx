import React from 'react'

export const Rules = () => {
  return (
    <div className='rules' style={{padding: '100px 20px'}}>
        <h1 style={{textAlign: 'center'}}>Пользовательские соглашения</h1>
    </div>
  )
}
