import React from 'react'

export const AboutPage = () => {
  return (
    <div className="about" style={{padding: "100px 20px"}}>
      <h1 style={{textAlign: 'center'}}>Страница о нашей компании</h1>
    </div>
  )
}