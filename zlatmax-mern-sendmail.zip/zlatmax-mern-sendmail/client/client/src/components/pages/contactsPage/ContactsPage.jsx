import React from 'react'

export const ContactsPage = () => {
  return (
    <div className="contacts" style={{padding: "100px 20px"}}>
      <h1 style={{textAlign: 'center'}}>Страница о контактах</h1>
    </div>
  )
}
