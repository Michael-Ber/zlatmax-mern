import React from 'react'

export const Flashlight = () => {
  return (
    <div className="flashlights" style={{padding: "100px 20px"}}>

      <h1 style={{textAlign: 'center'}}>Страница фонарей</h1>
    </div>
  )
}
