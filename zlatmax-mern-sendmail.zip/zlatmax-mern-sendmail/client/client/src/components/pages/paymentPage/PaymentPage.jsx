import React from 'react'

export const PaymentPage = () => {
  return (
    <div className="payment" style={{padding: "100px 20px"}}>

      <h1 style={{textAlign: 'center'}}>Странице об оплате и доставке</h1>
    </div>
  )
}