import React from 'react'

export const Page404 = () => {
  return (
    <div className='page404' style={{fontSize: "24px", textAlign: "center", fontWeight: "700", padding: "20px"}}>Страница не найдена...</div>
  )
}
