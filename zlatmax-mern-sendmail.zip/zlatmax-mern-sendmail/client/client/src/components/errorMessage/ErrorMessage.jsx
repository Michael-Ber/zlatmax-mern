import React from 'react'

export const ErrorMessage = () => {
  return (
    <div style={{textAlign: "center", fontSize: "26px", fontWeight: "700", padding: "20px"}} className='error-message'>Что-то пошло не так... :(</div>
  )
}
