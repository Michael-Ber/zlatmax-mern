import { Router } from "express";

const router = new Router();

router.post("/", () => {})

export default router;